
public class HelloWorld {

	
	public static void main(String[] argv) {
		System.out.println("Hello World!");
	}
}
