
public class MyInitials {

	public static void main(String[] args) {

	}
}
