public class FlowRate {

	public static double calculateFlow() {

		double pi = Math.PI;
		return -1;
	}
	
	public static void main(String[] args) {
		
		
		double flowRate = calculateFlow();
		System.out.println("The total flowRate in m^3/s is: ");

	}
}